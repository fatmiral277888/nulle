#pragma once

#define HTTP_SERVER "ip"
#define HTTP_PORT 80

#define TFTP_SERVER "ip"
